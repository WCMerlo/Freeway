//carros
let xCarros = [600, 600, 600,600, 600, 600];
let yCarros = [45, 105, 155, 215, 270, 310];
let velocidadeCarros = [6.5, 5, 4.8, 4.3, 3, 5];
let comprimentoCarrro = 40;
let alturaCarro = 30;

function mostraCarro(){
  for (let i = 0; i < imagemCarros.length; i++){    
    image(imagemCarros[i],  xCarros[i], yCarros[i], comprimentoCarrro, alturaCarro);

}
}
function movimentaCarro(){
  for ( let z = 0; z < xCarros.length; z++){
  xCarros[z]  -= velocidadeCarros[z];   
}
}

function voltaPosicaoInicialDoCarro(){
  for ( let i = 0; i < imagemCarros.length; i++){
  if (passouTodaTela(xCarros[i])){
     xCarros[i] = 600
    }
  }
}

function passouTodaTela(xCarros){
  return xCarros < -50;
}
